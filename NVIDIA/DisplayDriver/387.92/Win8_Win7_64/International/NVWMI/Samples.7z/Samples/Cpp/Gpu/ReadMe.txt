========================================================================
    CONSOLE APPLICATION : Gpu Project Overview
========================================================================

Gpu application demonstrates how to get WMI object properties of the Gpu class 
and how to invoke methods of this class


Gpu.vcxproj
    This is the main project file for VC++ projects.
    It contains information about the version of Visual C++ that generated the file, and
    information about the platforms, configurations, and project features.

Gpu.vcxproj.filters
    This is the filters file for VC++ projects. 
    It contains information about the association between the files in your project 
    and the filters. This association is used in the IDE to show grouping of files with
    similar extensions under a specific node (for e.g. ".cpp" files are associated with the
    "Source Files" filter).

Gpu.cpp
    This is the main application source file. It is written on C++11, but could be easily ported to the ANSI C.

